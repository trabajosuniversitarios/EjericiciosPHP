<!DOCTYPE html>
<html>
	<head>
		<title>Conversiones Metricas</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	</head>
	<body>
		<div class="container">
			<header class="jumbotron text-center">
				<h3>Tabla de Equivalencias de Volumenes, Longuitudes y Peso</h3>
			</header>
			<form class="form-group" method="post" action="conversiones.php">
				<div id="CargarDatos" class="text-center">
					<label >Selecione la equivalencia que desea calcular.</label>
					<br>
					<select name="optiones">
						<option value="1">Volumenes</option>
						<option value="2">Longuitudes</option>
						<option value="3">Peso-(Kg)</option>
					</select>
					<br>
					<br>
					<input type="submit"  name="Calcular">
				</div>
			</form>
		</div>
	</body>
</html>