<html>
	<head>
		<title>Conversiones Metricas</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	</head>
	<body>
		<div class="container">
			<header class="jumbotron text-center">
				<h3>Tabla de Equivalencias de Volumenes, Longuitudes y Peso</h3>
				<a href="index9.php">Regresar</a>
			</header>
			<div>
				<?php 
				 //Iniciaremos los calculos de para las diferentes tablas.
				 //Declaracion de las variables

				 //Los campos presentados hasta el momento, se de clararan globales
				 //Declararemos variables con las cuales se haran menciones de las funciones variables.
					

						/*Declaracion de las variables con las que se llamaran. las Funciones*/
						  /*------Llamamiento de la funcion longuitud------------*/
							$FuncionLonguitud = 'Longuitud';
							$FuncionLonguitud();
						  /*------Fin Llamamiento de la funcion longuitud------------*/
						  /*------Llamamiento de la funcion Volumenes------------*/
							$FuncionVolumenes = 'Volumenes';
							$FuncionVolumenes();
						  /*------Fin Llamamiento de la funcion Volumenes------------*/	
						  /*------Llamamiento de la funcion Peso------------*/
							$FuncionPeso = 'Peso';
							$FuncionPeso();
						  /*------Fin Llamamiento de la funcion Peso------------*/	
					/*--------------------LLamamiento de las funciones------------------------------*/

					function Longuitud(){
						$MultiOptions = $_POST['optiones'];
						/*valores establecidos para dichos procesos con longuitudes*/
						$metros =100;
						$pulgadas = 0.393701;
						$pies = 0.0328084;
						$yardas = 0.0109361;
						$centimetros = 0.25;
						//-----------------------
						$aumento = 0;
						//-----------------------
						
						/*Fin*/
						if ($MultiOptions == 2) {
							# code...
							for ($i = 1; $i <= 100; $i++) { 
								# code...
								$aumento += $centimetros;
								$meters = $aumento / $metros;
								$pulg = $aumento*$pulgadas;
								$pie = $aumento * $pies;
								$Yd = $aumento * $yardas;
								if($aumento <= 10){
									echo "<table class='table table-dark text-center'>
										  <thead>
										    <tr>
										      <th scope='col'>Centimetros</th>
										      <th scope='col'>Metros (Mts)</th>
										      <th scope='col'>Pulgadas (Pulg.)</th>
										      <th scope='col'>Pies (P)</th>
										      <th scope='col'>Yardas (Yd)</th>
										    </tr>
										  </thead>
										  <tbody>
										    <tr>
										      <th scope='row'>$aumento</th>
										      <td>$meters</td>
										      <td>$pulg</td>
										      <td>$pie</td>
										      <td>$Yd</td>
										    </tr>
										   
										  </tbody>
										</table>";	
								}		
							}
						}else{
						}
					}//Fin de la funcion Longuitud

					function Volumenes(){
						$MultiOptions = $_POST['optiones'];

						/*Valores establecidos para la tabla de Volumenes*/
						$centimetros = 0.25;
						$metroCubi = 1e-6;
						$milimetros = 1;
						$Litros = 0.001;
						$Galon = 0.000264172;
						$aumento = 0;
					/*Fin de los valores*/

						if ($MultiOptions == 1) {
							# code...
							for ($i = 1; $i <= 10; $i++) { 
								# code...
								$aumento += $centimetros;
								$metersCubi = $aumento / $metroCubi;
								$milimeters = $aumento*$milimetros;
								$litrs = $aumento * $Litros;
								$gal = $aumento * $Galon;
								if($aumento <= 10){
									echo "<table class='table table-dark text-center'>
										  <thead>
										    <tr>
										      <th scope='col'>Centimetros</th>
										      <th scope='col'>Metros Cubicos (Mts3)</th>
										      <th scope='col'>Milimitros</th>
										      <th scope='col'>Litros</th>
										      <th scope='col'>Galones</th>
										    </tr>
										  </thead>
										  <tbody>
										    <tr>
										      <th scope='row'>$aumento</th>
										      <td>$metersCubi</td>
										      <td>$milimeters</td>
										      <td>$litrs</td>
										      <td>$gal</td>
										    </tr>
										  </tbody>
										</table>";	
								}	
							}	
						}else{

						}
					}//Fin de la funcion Volumen

					function Peso(){
						$MultiOptions = $_POST['optiones'];
						/*Valores para la conversion de Peso(Kg)*/
						$miligramos = 0.25;
						$gramos = 0.001;
						$onzas = 3.5274e-5;
						$libra = 2.2046e-6;
						$aumento = 0;

						/*Fin*/
						if ($MultiOptions == 3) {
							# code...
							for ($i = 1; $i <= 10; $i++) { 
								# code...
								$aumento += $miligramos;
								$Grams = $aumento / $gramos;
								$onza = $aumento*$onzas;
								$libras = $aumento * $libra;
								if($aumento <= 10){
									echo "<table class='table table-dark text-center'>
										  <thead>
										    <tr>
										      <th scope='col'>Miligramos</th>
										      <th scope='col'>Gramos (g)</th>
										      <th scope='col'>Onzas (Oz)</th>
										      <th scope='col'>Libra (lb)</th>
										    </tr>
										  </thead>
										  <tbody>
										    <tr>
										      <th scope='row'>$aumento</th>
										      <td>$Grams</td>
										      <td>$onza</td>
										      <td>$libras</td>
										    </tr>
										  </tbody>
										</table>";	
								}	
							}
						}else{
							echo "Error!!";
						}
					}
				 ?>		
			</div>
		</div>
	</body>
</html>


	
