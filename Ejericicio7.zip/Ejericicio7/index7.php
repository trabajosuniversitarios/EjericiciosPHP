<!DOCTYPE html>
<html>
	<head>
		<title>Conversiones Metricas</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	</head>
	<body>
		<div class="container">
			<header class="jumbotron text-center">
				<h3>Inscripcion de nuevo Ingreso, Tecnico en Ciencia de la Computacion</h3>
			</header>
			<form class="form-group" method="post" action="alumno.php">
				<div id="CargarDatos" class="text-center">
					<div class="list-group">
					  <ul class="list-group">
						  <li class="list-group-item active">Vista del menu de las Materias a Incsribir</li>
						  <li class="list-group-item">1. Antropología Filosófica</li>
						  <li class="list-group-item">2. Lenguajes de Marcado y Estilo Web</li>
						  <li class="list-group-item">3. Matemática Discreta</li>
						  <li class="list-group-item">4. Programación de Algoritmos</li>
						  <li class="list-group-item">5. Redes de Comunicación</li>
					  </ul>
					</div>
					<br>
					<br>
					<h4>Inscripcion de Materias.</h4>
					<div class="card text-white bg-warning mb-3" >
					  <div class="card-header">Recordatorios</div>
					  <div class="card-body">
					    <h5 class="card-title">Warning!</h5>
					    <p class="card-text">Solo marcara, las materias que posean Laboratorio, el costo por laboratorio es de $33 Dolares..</p>
					  </div>
					</div>
					<br>
					<table class="table table-hover table-center table-primary">
					  <thead>
					    <tr>
					      <th scope="col">#</th>
					      <th scope="col">Materias Disponibles</th>
					      <th scope="col">Posee Laboratorio.</th>
					    </tr>
					  </thead>
					  <tbody>
					    <tr>
					      <th scope="row">1</th>
					      <td><input type="text" class="form-control" placeholder="Ingrese Nombre por Favor de la Materia 1" name="materia1"  required="required"></td>
					      <td>
					      	<input class="form-check-input" type="checkbox" name="AF" value="1">
					      </td>
					    </tr>
					    <tr>
					      <th scope="row">2</th>
					      <td><input type="text" class="form-control" placeholder="Ingrese Nombre por Favor de la Materia 2" name="materia2" required="required"></td>
					      <td><input class="form-check-input" type="checkbox" name="LME" value="2"></td>
					    </tr>
					    <tr>
					      <th scope="row">3</th>
					      <td><input type="text" class="form-control" placeholder="Ingrese Nombre por Favor de la Materia 3" name="materia3" required="required"></td>
					      <td><input class="form-check-input" type="checkbox" name="MD" value="3"></td>
					    </tr>
					    <tr>
					      <th scope="row">4</th>
					      <td><input type="text" class="form-control" placeholder="Ingrese Nombre por Favor de la Materia 4" name="materia4" required="required"></td>
					      <td><input class="form-check-input" type="checkbox" name="PAL" value="4"></td>
					    </tr>
					    <tr>
					      <th scope="row">5</th>
					      <td><input type="text" class="form-control" placeholder="Ingrese Nombre por Favor de la Materia 5" name="materia5" required="required"></td>
					      <td><input class="form-check-input" type="checkbox" name="REC" value="5"></td>
					    </tr>
					  </tbody>
					</table>
					<br>
					<div class="row">
						<div class="col-md-6 text-center">
							<label>Costo de Ingreso:</label>
							<input type="text" class="text-center" name="cuotafija" disabled="" value="70">
						</div>
						<div class="col-md-6 text-center">
							<label>Ingrese Cuota Mensual ($) Min $50 - Max $250</label>
							<input type="number" class="text-center" name="CMensual" min="59" step="0.01" required="required" max="250">
						</div>
					</div>
					<br>
					<button type="submit" class="form-control btn-primary">Inscribir.</button>
				</div>
			</form>
		</div>
	</body>
</html>