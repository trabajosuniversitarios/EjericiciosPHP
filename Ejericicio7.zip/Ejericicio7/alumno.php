<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<?php 
	//Creacion de proceso para los calculos de las materias.
	$af = isset($_REQUEST['AF']);
	$lme = isset($_REQUEST['LME']);
	$md = isset($_REQUEST['MD']);
	$pal = isset($_REQUEST['PAL']);	
	$rec = isset($_REQUEST['REC']);
	$mat1 = $_POST['materia1'];
	$mat2 = $_POST['materia2'];
	$mat3 = $_POST['materia3'];
	$mat4 = $_POST['materia4'];
	$mat5 = $_POST['materia5'];
	$CostoLaboratorio = 33;
	$IngresoFijo = 70;
	$cuotamensual = $_POST['CMensual'];
	$totaLab = 0;
	$total = 0;

	$cuotaInicio = isset($_REQUEST['cuotafija']);
	if ($af == 1){
      $materia = "La materia posee laboratorio";
      $totaLab = $CostoLaboratorio;
	}else{
		$materia = "La materia, no posee Laboratorio";
	}
	if($lme == 2){
		$materia2 = "La materia, posee Laboratorio";
		$totaLab += $CostoLaboratorio;
	}
	else{
		$materia2 = "La materia, no posee Laboratorio";	
	}
	if ($md == 3){
      echo "La Materia no posee laboratorio";
      $totaLab +=$CostoLaboratorio;
	}
	else{
		$materia3 = "La materia, no posee Laboratorio";
	}
	if ($pal == 4) {
		# code...
		$materia4 = "La materia, posse Laboratorio";
		$totaLab += $CostoLaboratorio;
	}
	else{
		$materia4 = "La materia, no posse Laboratorio";
	}
	if ($rec == 5) {
		# code...
		$materia5 = "La materia, posee Laboratorio <br>";
		$totaLab += $CostoLaboratorio;
	}
	else{
		$materia5 = "La materia, no posse Laboratorio";
	}

	//Total a cancelar 
	$total = $totaLab + $cuotamensual + $IngresoFijo;
	echo "<div class='container'>
			<table class='table table-bordered table-primary'>
			  <thead class='text-center'>
			    <tr>
			      <th scope='col'>#</th>
			      <th scope='col'>Materias Inscritas</th>
			      <th scope='col'>Laboratorios</th>
			      <th scope='col'>Total a Cancelar</th>
			    </tr>
			  </thead>
			  <tbody class='text-center'>
			    <tr>
			      <th scope='row'>1</th>
			      <td>$mat1</td>
			      <td>$materia</td>
			    </tr>
			    <tr>
			      <th scope='row'>2</th>
			      <td>$mat2</td>
			      <td>$materia2</td>
			    </tr>
			    <tr>
			      <th scope='row'>3</th>
			      <td>$mat3</td>
			      <td>$materia3</td>
			    </tr>
			    <tr>
			      <th scope='row'>4</th>
			      <td>$mat4</td>
			      <td>$materia4</td>
			    </tr>
			    <tr>
			      <th scope='row'>5</th>
			      <td>$mat5</td>
			      <td>$materia5</td>
			      <td>Total a cancelar:$ $total </td>
			    </tr>
			  </tbody>
			</table>
		  </div>";
 ?>
